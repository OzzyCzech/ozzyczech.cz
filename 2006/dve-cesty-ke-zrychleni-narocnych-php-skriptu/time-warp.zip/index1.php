<?php
/**
 * Čteni RSS zdrojů pomocí CRUL knihovny
 * 
 * www.nabito.net
 * admin@nabito.net
 * @version 1.0
 * @author Roman Ožana
 * @copyright Roman Ožana
 */
require_once('./xhtml.php');

$xhtml = new xhtml('','','');
$xhtml->add_to_javascript('tw-sack.js'); // pridani ajaxu
$xhtml->get_header();
$opml = simplexml_load_file('export.xml');

foreach ($opml->body->outline->outline as $main_outline)
{
	if ($main_outline['text'] == 'GIS 2')
	{
		foreach ($main_outline as &$item)
		{
			if ($item['type'] == 'rss') $connomains[] = 'http://www.nabito.net/rssagr/getfeed.php?feed='.rawurlencode($item['xmlUrl']);
		}

		$mh = curl_multi_init();

		foreach ($connomains as $i => $url) 
		{
			$conn[$i]=curl_init($url);
			curl_setopt($conn[$i],CURLOPT_RETURNTRANSFER,1);
			curl_multi_add_handle ($mh,$conn[$i]);
		}

		do { $n=curl_multi_exec($mh,$active);} while ($active);

		foreach ($connomains as $i => $url) {
			$res[$i]=curl_multi_getcontent($conn[$i]);
			curl_close($conn[$i]);
		}
		foreach ($res as $result)
		{
			if ($result != 'nothing') echo $result;
		}
	}
}

$xhtml->get_footer();
?>