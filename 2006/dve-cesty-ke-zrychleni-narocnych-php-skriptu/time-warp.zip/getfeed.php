<?php
/**
 * www.nabito.net
 * admin@nabito.net
 * @version 1.0
 * @author Roman Ožana
 * @copyright Roman Ožana
 */
require_once('./httprequest.php');
// POST
if (isset($_POST['feed'])) $file = new HTTPRequest(urldecode($_POST['feed']));
// GET
if (isset($_GET['feed'])) $file = new HTTPRequest(urldecode($_GET['feed']));

$feed_source = @simplexml_load_string($file->DownloadToString());

$main = $feed_source->channel;
$items = $feed_source->channel->item;
$one_title = true;
if (is_object($items))
foreach ($items as $item)
{
	$counter = 0;
	if (date('Y_W',time()) == date('Y_W',strtotime($item->pubDate)))
	{
		if ($one_title == true)
		{
			echo'<h1>'.$main->title.'</h1>';
			$one_title = false;
		}
		echo '<div>';
		echo '<h2><a href="'.$item->link.'">'.$item->title.'</a></h2>';
		echo '<p>';
		echo $item->description;
		echo '</p>';
		echo '</div>';
		$counter++;
	}
}
if ($counter == 0) echo 'nothing';
?>