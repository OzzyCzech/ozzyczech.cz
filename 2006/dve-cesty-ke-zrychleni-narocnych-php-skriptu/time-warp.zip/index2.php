<?php
/**
 * Klasické čtení RSS Zdrojů - dá si skutečně na Čas
 * 
 * www.nabito.net
 * admin@nabito.net
 * @version 1.0
 * @author Roman Ožana
 * @copyright Roman Ožana
 */
require_once('./xhtml.php');
require_once('./httprequest.php');

$xhtml = new xhtml('','','');
$xhtml->get_header();
$opml = simplexml_load_file('export.xml');

foreach ($opml->body->outline->outline as $main_outline)
{
	if ($main_outline['text'] == 'GIS 2')
	{
		foreach ($main_outline as &$feed)
		{
			$file = new HTTPRequest($feed['xmlUrl']);
			
			$feed_source = @simplexml_load_string($file->DownloadToString());
			
			$main = $feed_source->channel;
			$items = $feed_source->channel->item;
			
			$one_title = true;
			if (is_object($items))
			foreach ($items as $item)
			{
				$counter = 0;
				if (date('Y_W',time()) == date('Y_W',strtotime($item->pubDate)))
				{
					if ($one_title == true)
					{
						echo'<h1>'.$main->title.'</h1>';
						$one_title = false;
					}
					echo '<div>';
					echo '<h2><a href="'.$item->link.'">'.$item->title.'</a></h2>';
					echo '<p>';
					echo $item->description;
					echo '</p>';
					echo '</div>';
					$counter++;
				}
			}
			if ($counter == 0) echo 'nothing';
		}
	}
}
$xhtml->get_footer();
?>