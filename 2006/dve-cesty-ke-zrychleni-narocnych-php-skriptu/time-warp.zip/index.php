<?php
/**
 * Čtení RSS zdojů pomocí AJAX technologie
 * 
 * www.nabito.net
 * admin@nabito.net
 * @version 1.0
 * @author Roman Ožana
 * @copyright Roman Ožana
 */
require_once('./xhtml.php');

$xhtml = new xhtml('','','');
$xhtml->add_to_javascript('tw-sack.js'); // pridani ajaxu
$xhtml->get_header();
$opml = simplexml_load_file('export.xml');
echo '<div id="icon" style="float:right;"></div><input type="button" value="Start/Stop" onclick="start_stop()" />
	<div id="status" style="margin-top:5px;background-color:red;height:10px;width:100%;"></div>';
echo '<div id="replaceme"></div>';
foreach ($opml->body->outline->outline as $main_outline)
{
	if ($main_outline['text'] == 'GIS 2')
	{
		$counter = 1;
		/*foreach ($main_outline as $item)
		{
		echo '<div id="item'.$counter.'">'.$item['txitle'].'</div>'."\n";
		$counter++;
		}


		*/
		echo '<script type="text/javascript">';

		echo "var urls = new Array();\n";
		echo "var position = 0;\n";
		echo "var runsearch = true;\n";
		
		$counter = 0;
		foreach ($main_outline as $item)
		{
			if ($item['type'] == 'rss')
			{
				echo "urls['".$counter."'] = '".$item['xmlUrl']."';\n";
			}
			$counter++;
		}

		echo "
		var ajax = new sack();
	
		function completed()
		{
			var output = document.getElementById('replaceme');
			var status = document.getElementById('status');
			
			if (ajax.responseStatus)
			{
				if (ajax.response != 'nothing')
				{				
					output.innerHTML = ajax.response + output.innerHTML;
				}
			}
			if ( (position < $counter) && (runsearch == true) )
			{
				position = position+1;
				status.style.width = (100-((100 * position)/$counter)) + '%';		
				ajax.reset();
				check();
			}
		}
		
		function check()
		{
			ajax.setVar('feed', urls[position]);
			ajax.requestFile = 'getfeed.php';
			ajax.method = 'POST';
			ajax.onCompletion = completed;
			ajax.runAJAX();
		}
		function start_stop()
		{
			if (runsearch == true)
			{
			 	document.getElementById('icon').innerHTML = '';
				runsearch = false;
			} else 
			{
				document.getElementById('icon').innerHTML = '<img src=\"arrows.gif\" alt=\"Arrows\" />';
				runsearch = true;
				ajax.reset();
				check();
			}
		}
		start_stop();
		";
		echo '</script>';
	}
}

$xhtml->get_footer();
?>