<?php
/**
 * XHTML Generator file
 * @version  3.2
 * @author Roman Ožana
 * @todo  compression function or switch
 * 
 */
class xhtml
{
	/**
	 * base URL http://www.nabito.net/
	 *
	 * @var unknown_type
	 */
	public $BASE_url	 			= '';
	/**
	 * postfix in title Title - nabito.net
	 *
	 * @var unknown_type
	 */
	public $BASE_name 			= '';
	/**
	 * DUBLIN CORE Title - This is exmple page
	 *
	 * @var unknown_type
	 */
	public $DCtitle					= '';
	/**
	 * DUBLIN CORE Creator - Roman Ozana
	 *
	 * @var unknown_type
	 */
	public $DCcreator				= 'Roman Ožana';
	/**
	 * DUBLIN CORE Subject - DCMI; Dublin Core Metadata Initiative; DC META Tags
	 *
	 * @var unknown_type
	 */
	public $DCsubject 			= '';
	/**
	 * DUBLIN CORE Description - Examples of Dublin Core META Tags
	 *
	 * @var unknown_type
	 */
	public $DCdescription 	= '';
	/**
	 * DUBLIN CORE Publisher - nabito.net blog
	 *
	 * @var unknown_type
	 */
	public $DCpublisher			=	'';
	/**
	 * DUBLIN CORE Contributor - DCMI Dublin Core Metadata Initiative - person, an organization, or a service. Typically, the name of a Contributor should be used to indicate the entity
	 *
	 * @var unknown_type
	 */
	public $DCcontributor   =	'Roman Ožana';
	/**
	 * DUBLIN CORE Date - 2004-12-31 - date YYYY-MM-DD
	 *
	 * @var unknown_type
	 */
	public $DCdate					= '';
	/**
	 * DUBLIN CORE type - 99% chance no change
	 *
	 * @var unknown_type
	 */
	public $DCtype					=	'Text';
	/**
	 * DUBLIN CORE Format - MIME type 99% chance no change
	 *
	 * @var unknown_type
	 */
	public $DCformat				=	'text/html';
	/**
	 * DUBLIN CORE Identifier - http://www.nabito.net/index.php - URI, URL, DOI ...
	 *
	 * @var unknown_type
	 */
	public $DCidentifier		=	'';
	/**
	 * DUBLIN CORE Source - http://www.nabito.net/index.php - may be derived from the Source resource in whole or in part
	 *
	 * @var unknown_type
	 */
	public $DCsource				= '';
	/**
	 * DUBLIN CORE Language - en, cs ... ISO639 http://www.seoconsultants.com/meta-tags/language.asp
	 *
	 * @var unknown_type
	 */
	public $DClanguage			= 'cs';
	/**
	 * DUBLIN CORE Relation - http://www.nabito.net - identify the referenced resource
	 *
	 * @var unknown_type
	 */
	public $DCrelation			=	'';
	/**
	 * DUBLIN CORE Coverage - a place name or geographic coordinates
	 *
	 * @var unknown_type
	 */
	public $DCcoverage			= 'Czech Republic';
	/**
	 * DUBLIN CORE Rights - Rights will contain a rights management statement for the resource, or reference a service providing such information.
	 *
	 * @var unknown_type
	 */
	public $DCrights				= '';
	/**
	 * switch on/off dubline metadata
	 *
	 * @var unknown_type
	 */
	public $DC_show					=	false;
	/**
	 * XHTML Doctype strict/transitional
	 *
	 * @var unknown_type
	 */
	public $XHDoctype				= 'strict';
	/**
	 * Language cs, en ...
	 *
	 * @var unknown_type
	 */
	public $XHLanguage			= 'cs';
	/**
	 * TAG title
	 *
	 * @var unknown_type
	 */
	public $XHTitle				  = '';
	/**
	 * Meta Autor
	 *
	 * @var unknown_type
	 */
	public $XHAutor					= 'Roman Ožana';
	/**
	 * Email to administrator
	 *
	 * @var unknown_type
	 */
	public $XHAutorEmail		= 'admin@nabito.net';
	/**
	 * Encodyng - UTF8 Default
	 *
	 * @var unknown_type
	 */
	public $XHEncodyng			= 'utf-8';
	/**
	 * Generator identification
	 *
	 * @var unknown_type
	 */
	public $XHGenerator			= 'SciTE - http://www.scintilla.org';
	/**
	 * Revisit datum (15 days ...)
	 *
	 * @var unknown_type
	 */
	public $XHrevisit				= '';
	/**
	 * Keywords array or string with coma separator
	 *
	 * @var unknown_type
	 */
	public $XHKeywords				= array();
	/**
	 * Short page description
	 *
	 * @var unknown_type
	 */
	public $XHDescription		= '';
	/**
	 * Default CSS media array array('screen' => './style.css');
	 *
	 * @var unknown_type
	 */
	public $css_media 			= array('screen' => './style.css', 'print' => './print.css');
	/**
	 * Add another CSS to show medium $css_array[] = 'xx.css';
	 *
	 * @var unknown_type
	 */
	public $css_array				= array(); // $css_array[] = 'xx.css';
	/**
	 * Javascripts array - $javascripts[] = 'javascript.js';
	 *
	 * @var unknown_type
	 */
	private $javascripts			= array(); // $javascripts[] = 'javascript.js';
	/**
	 * HTML Icon
	 *
	 * @var unknown_type
	 */
	public $icon						= './icon.png';
	/**
	 * Add string to header
	 *
	 * @var unknown_type
	 */
	public $to_header				= '';
	/**
	 * Fi and Lambda in array('49.82700','18.26954') require switch DC_show to true
	 *
	 * @var unknown_type
	 */
	public $coordinate			= array('49.82700','18.26954');
	/**
	 * Robots setings array('noindex' => false, 'noflow' => false, 'none' => false);
	 *
	 * @var unknown_type
	 */
	public $robots					= array('noindex' => false, 'noflow' => false, 'none' => false);
	/**
	 * Navigation array('homepage' => 'index.php'); next switch is :
	 * <ol>
	 * <li>alternate</li>
	 * <li>stylesheet</li>
	 * <li>start</li>
	 * <li>next</li>
	 * <li>prev</li>
	 * <li>contents</li>
	 * <li>chapter</li>
	 * <li>section</li>
	 * <li>subsection</li>
	 * <li>appendix</li>
	 * <li>help</li>
	 * <li>bookmark</li>
	 * <li>index</li>
	 * <li>glossary</li>
	 * <li>copyright</li>
	 * </ol>
	 * @var unknown_type
	 */
	public $navigation 			= array('homepage' => 'index.php');
	/**
	 * FEEDs - RSS2, ATOM, RSS92 - array('RSS2' => 'test');
	 *
	 * @var unknown_type
	 */
	public $feed 				=	array();
	/**
	 * Result string
	 *
	 * @var unknown_type
	 */
	public $result_string		= '';
	/**
	 * Error result string
	 *
	 * @var unknown_type
	 */
	public $err_result 			= '';
	/**
	 * show error direct in HTML of like comments in HTML
	 *
	 * @var unknown_type
	 */
	public $showerror				= false;	//
	//
	/**
	 * for script duration - start time
	 */
	private $start 					= 0;
	/**
	 * for script duration - end time
	 *
	 * @var unknown_type
	 */
	private $stop 					= 0;
	/**
 * Contructor create new page
 *
 * @param unknown_type $title
 * @param unknown_type $description
 * @param unknown_type $keywords
 * @return xhtml
 */
	function xhtml($title = "", $description = "", $keywords = "" )
	{
		$this->start = microtime(true); // Start Time
		$this->XHTitle = $title;
		$this->XHDescription = $description;
		$this->XHKeywords = $keywords; // split keywords
	}
	/**
 	 * Return XHTML Header
   *
   * @param unknown_type $echo
   */
	function get_header($echo = true)
	{
		// xml head
		$this->result_string = '<?xml version="1.0" encoding="'.$this->XHEncodyng.'"?>'."\n"; // begin of XHTML
		// XHTML Doctype
		switch ($this->XHDoctype)
		{
			case 'strict':
				$this->result_string .= '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.orgR/xhtml1/DTD/xhtml1-strict.dtd">'."\n";
				break;
			case 'transitional':
			default:
				$this->result_string .= '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.orgR/xhtml1/DTD/xhtml1-transitional.dtd">'."\n";
				break;
		}
		// xhtml head
		$this->result_string .= '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$this->XHLanguage.'" lang="'.$this->XHLanguage.'">'."\n";
		$this->result_string .= '<head>'."\n";
		// XHTML title
		if (empty($this->XHTitle))
		{
			$this->write_error('TAG : title is empty'); // ERROR
		} else
		{
			$this->result_string .= "\t".'<title>'.$this->XHTitle;
			if (!empty($this->BASE_name))
			{
				$this->result_string .= ' - '.$this->BASE_name;
			}
			$this->result_string .= '</title>'."\n"; // title
		}
		// base meta tags
		$this->result_string .= "\t".'<!--BASE METATAGS-->'."\n";
		$this->result_string .= "\t".'<meta http-equiv="content-type" content="text/html; charset='.$this->XHEncodyng.'" />'."\n"; // encodyng
		$this->result_string .= "\t".'<meta http-equiv="content-language" content="'.$this->XHLanguage.'" />'."\n"; // language
		$this->result_string .= "\t".'<meta name="author" content="All: '.$this->XHAutor.'; e-mail: '.$this->XHAutorEmail.'" />'."\n"; // autor
		$this->result_string .= "\t".'<meta name="copyright" content="'.$this->XHAutor.'; e-mail: '.$this->XHAutorEmail.'" />'."\n";
		$this->result_string .= "\t".'<meta name="generator" content="'.$this->XHGenerator.'" />'."\n"; // generator
		if (empty($this->XHDescription))
		{
			$this->write_error('META : description is empty');
		} else
		{
			$this->result_string .= "\t".'<meta name="description" content="'.$this->XHDescription.'" />'."\n";
		}
		// REVISION
		if (!empty($this->XHrevisit)) { $this->result_string .= "\t".'<meta name="revisit-after" content="'.$this->XHrevisit.'">'."\n";}
		// KEYWORDS
		$this->result_string .= "\t".'<meta name="keywords" content="';
		if (empty($this->XHKeywords))
		{
			$this->write_error('META : keyword is empty');
		} else
		{
			if (!is_array($this->XHKeywords)) {$this->XHKeywords = split(',',$this->XHKeywords);}
			foreach ($this->XHKeywords as $keyword)
			{
				if (!empty($keyword))
				{
					$this->result_string  .= $keyword.','; // add keyword
				}
			}
			$this->result_string  .= '" />'."\n";
		}
		// NOINDEX
		if ($this->robots['noindex'] == true )
		{
			$this->result_string .= "\t".'<meta name="robots" content="noindex">'."\n";
		}
		// NOFLOW
		if ($this->robots['noflow'] == true)
		{
			$this->result_string .= "\t".'<meta name="robots" content="nofollow">'."\n";
		}
		// ROBOTS NONE
		if ($this->robots['none'] == true)
		{
			$this->result_string .= "\t".'<meta name="robots" content="none">'."\n";
		}
		// DUBLIN CORE
		if ($this->DC_show == true)
		{
			// POSITION
			$this->result_string .= "\t".'<!-- WEB POSITION -->'."\n";
			$this->result_string .= "\t".'<meta name="ICBM" content="'.$this->coordinate[0].', '.$this->coordinate[1].'">'."\n";
			// DUBLIN CORE
			$this->result_string .= "\t".'<!-- DUBLIN CORE -->'."\n";
			$this->result_string .= "\t".'<meta name="DC.title" lang="'.$this->DClanguage.'" content="'.$this->DCtitle.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.creator" content="'.$this->DCcreator.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.subject" lang="'.$this->DClanguage.'" content="'.$this->DCsubject.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.description" lang="'.$this->DClanguage.'" content="'.$this->DCdescription.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.publisher" content="'.$this->DCpublisher.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.contributor" content="'.$this->DCcontributor.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.date" scheme="W3CDTF" content="'.$this->DCdate.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.type" scheme="DCMIType" content="'.$this->DCtype.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.format" scheme="IMT" content="'.$this->DCformat.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.identifier" content="'.$this->DCidentifier.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.source" content="'.$this->DCsource.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.language" scheme="RFC1766" content="'.$this->DClanguage.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.relation" content="'.$this->DCrelation.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.coverage" content="'.$this->DCcoverage.'">'."\n";
			$this->result_string .= "\t".'<meta name="DC.rights" content="'.$this->DCrights.'">'."\n";

			if (empty($this->DClanguage)) {$this->write_error('DC : language parametr is empty');}
			if (empty($this->DCcreator)) {$this->write_error('DC : autor parametr is empty');}
			if (empty($this->DCsubject)) {$this->write_error('DC : subject parametr is empty');}
			if (empty($this->DCdescription)) {$this->write_error('DC : description parametr is empty');}
			if (empty($this->DCpublisher)) {$this->write_error('DC : publisher parametr is empty');}
			if (empty($this->DCcontributor)) {$this->write_error('DC : contributor parametr is empty');}
			if (empty($this->DCdate)) {$this->write_error('DC : date parametr is empty');}
			if (empty($this->DCtype)) {$this->write_error('DC : type parametr is empty');}
			if (empty($this->DCformat)) {$this->write_error('DC : format parametr is empty');}
			if (empty($this->DCidentifier)) {$this->write_error('DC : identifier parametr is empty');}
			if (empty($this->DCsource)) {$this->write_error('DC : source parametr is empty');}
			if (empty($this->DCrelation)) {$this->write_error('DC : relation parametr is empty');}
			if (empty($this->DCcoverage)) {$this->write_error('DC : coverage parametr is empty');}
			if (empty($this->DCrights)) {$this->write_error('DC : rights parametr is empty');}
		}
		// ICON
		if (!file_exists($this->icon))
		{
			$this->write_error('ICON : icon file '.$this->icon.' not exists');
		} else
		{
			$this->result_string .= "\t".'<!--ICON-->'."\n";
			$this->result_string .= "\t".'<link rel="shortcut icon" href="'.$this->icon.'" type="image/x-icon" />'."\n";
		}
		// CSS styles
		if (!empty($this->css_media))
		{
			$this->result_string .= "\t".'<!-- CSS MEDIA -->'."\n";
			foreach ($this->css_media as $media => $css)
			{
				if (file_exists($css))
				{
					$this->result_string .= "\t".'<link rel="stylesheet" href="'.$css.'"  media="'.$media.'" type="text/css" />'."\n";
				} else
				{
					$this->write_error("CSS : media $media file $css not exists, ");
				}
			}
		}
		// CSS MEDIA SCREEN
		if (!empty($this->css_array))
		{
			$this->result_string .= "\t".'<!-- CSS SCREEN -->'."\n";
			foreach ($this->css_array as $css)
			{
				if (file_exists($css))
				{
					$this->result_string .= "\t".'<link rel="stylesheet" href="'.$css.'"  media="screen" type="text/css" />'."\n";
				} else
				{
					$this->write_error("CSS :  media screen file $css not exists");
				}
			}
		}
		// FEED RESOURCE
		if (!empty($this->feed))
		{
			$this->result_string .= "\t".'<!-- FEEDS -->'."\n";
			foreach ($this->feed as $type => $feed)
			{
				switch ($type)
				{
					case 'RSS2': //RSS 2
					$this->result_string .= "\t".'<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="'.$feed.'">'."\n";
					break;
					case 'ATOM': //ATOM
					$this->result_string .= "\t".'<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="'.$feed.'">'."\n";
					break;
					case 'RSS92': //RSS 0.92
					$this->result_string .= "\t".'<link rel="alternate" type="application/xml" title="RSS .92" href="'.$feed.'">'."\n";
					break;
				}
			}
		}
		// NAVIGATION
		if (!empty($this->navigation))
		{
			$this->result_string .= "\t".'<!-- NAVIGATION -->'."\n";
			foreach ($this->navigation as $rel => $href)
			{
				if (file_exists($href))
				{
					$this->result_string .= "\t".'<link rel="'.$rel.'" href="'.$href.'" />'."\n";
				} else
				{
					$this->write_error("NAVIGATION :  $rel : $href file not exists");
				}
			}
		}
		// JAVASCRIPTS
		if (!empty($this->javascripts))
		{
			$this->result_string .= "\t".'<!-- JAVASCRIPTS -->'."\n";
			foreach($this->javascripts as $js_script)
			{
				if (file_exists($js_script))
				{
					$this->result_string .= "\t".'<script type="text/javascript" src="'.$js_script.'"></script>'."\n";
				} else
				{
					$this->write_error("JAVASCRIPT : not exsists file $js_script");
				}

			}
		}
		$this->result_string .= $to_header; // add something to header
		$this->result_string .= '</head>'."\n"; // HEAD END
		$this->result_string .= '<body>'."\n"; // BODY

		if ($echo == true)
		{
			echo $this->result_string;
			$this->result_string = ''; // empty trash
		}
	}
	/**
	 * Return XHTML footer
	 *
	 * @param unknown_type $echo
	 */
	function get_footer($echo = true)
	{
		$this->stop = microtime(true);
		if (!empty($this->err_result))
		{
			if ($this->showerror) // ERROR
			{
				$this->result_string .= '<p style="background-color:#990000;color:white;padding:10px;font-weight:bold;font-family:verdana;font-size:small;">'.$this->err_result.'</p>';
			} else
			{
				$this->result_string .= "<!-- ERROR REPORT ".$this->err_result."\n-->\n";
			}
		}
		$this->result_string .= '<!-- Author : Roman Ožana, '.date('Y').' - http://www.nabito.net/ admin@nabito.net -->'."\n";
		$this->result_string .= '<!-- Last modified : '.date('j.n.Y H:i:s', filemtime(basename($_SERVER['PHP_SELF']))).'-->'."\n";
		$this->result_string .= '<!-- Base url : '.$this->BASE_url.' -->'."\n";
		$this->result_string .= '<!-- Script run : '.($this->stop - $this->start).' -->'."\n";
		$this->result_string .= "</body>\n</html>\n";
		if ($echo == true)
		{
			echo $this->result_string;
			$this->result_string = ''; // empty trash
		}
	}
	/**
	 * Write error to error string
	 *
	 * @param unknown_type $error_text
	 */
	function write_error($error_text)
	{
		if ($this->showerror)
		{
			$this->err_result .= $error_text.'<br />';
		} else
		{
			$this->err_result .= "\n\t".$error_text;
		}
	}
	/**
	 * Stara se o pridavani dat do css
	 *
	 * @param unknown_type $data
	 */
	function add_to_css($data = array())
	{
		if (is_string($data))
		{
			$this->css_array[] = $data;
		} else 
		{
			$this->css_array = array_merge($this->css_array, $data);	
		}
	}
	function add_to_javascript($data = array())
	{
		if (is_string($data))
		{
			$this->javascripts[] = $data;
		} else 
		{
			$this->javascripts = array_merge($this->javascripts, $data);	
		}
	}
} // end of class
?>